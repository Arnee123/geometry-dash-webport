GEOMETRY DASH WEBPORT — VERCEL PROJECT

WHAT THIS PROJECT DOES
- Serves the supplied Geometry Dash webport HTML from your own Vercel project URL.
- Keeps the in-game fullscreen and save/reset controls already present in the supplied HTML.
- Uses a no-store cache policy for the main page so updated HTML is picked up more reliably.

IMPORTANT LIMITATION
This is a self-hosted HTML shell, not a complete mirror of every game asset. The supplied HTML loads the webport's external game resources from the upstream public asset host (including its WASM/data files). An internet connection is required, and those upstream resources remain controlled by their hosts. Hosting this shell on Vercel does not guarantee that the upstream assets will remain available or fix a browser/WebAssembly crash.

DEPLOY TO VERCEL
1. Extract this ZIP.
2. Put the extracted files in a new GitHub repository (the files index.html and vercel.json must be at the repository root).
3. In Vercel, choose Add New -> Project and import that GitHub repository.
4. Choose the static/Other framework preset if asked. Leave Build Command and Output Directory blank/default; no build step is required.
5. Deploy. Vercel will give the project its own .vercel.app URL.

The project does not include a Vercel account login or publish anything automatically.

CREDITS / RIGHTS
This is an unofficial browser webport. Geometry Dash and its original game assets belong to their respective rights holders. This package does not include the original game's proprietary asset bundle; the HTML requests resources from the upstream host. Keep the original webport credits and notices intact.
